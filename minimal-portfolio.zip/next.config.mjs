/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    unoptimized: true,

    domains: ['kfowfrynubrxhzgpvjuy.supabase.co']
  },
};

export default nextConfig;